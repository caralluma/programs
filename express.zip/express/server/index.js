var App = require("./app.js");
var Configuration = require("./config");

App.listen(Configuration.HTTP_PORT, () => {
    console.log(`App started at port ${Configuration.HTTP_PORT}`);
});


