var config = {

    HTTP_PORT : 3000

};

module.exports = config;

/*
var config =  function() {
    const self = {};

    self.HTTP_PORT  = 3000;

    return self;
};

 module.exports = config;

 */

