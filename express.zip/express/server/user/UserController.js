var App = require("../app.js");

App.get("/", function (req, res) {
    res.send("Hello world 2");
});

App.post();

module.exports = App;

